package com.digitalbooks.book.entity;

import lombok.Data;

@Data
public class Book {

	private int bookId;
	private String title;
	private String category;
	private String image;
	private double price;
	private String publisher;
	private String author;
	private String active;
	private String content;
}
