package com.digitalbooks.book.service;

import com.digitalbooks.book.dto.ResponseDto;
import com.digitalbooks.book.entity.User;

public interface UserService {

	User saveUser(User user);
    //ResponseDto getUser(Long userId);
}
