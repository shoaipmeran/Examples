import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Book } from '../module/book';
import { BookserviceService } from '../service/bookservice.service';

@Component({
  selector: 'app-addbook',
  templateUrl: './addbook.component.html',
  styleUrls: ['./addbook.component.scss']
})
export class AddbookComponent implements OnInit {
 
   book:Book=new Book();

  constructor(private  bookService:BookserviceService, private router:Router) { }

  ngOnInit(): void {
  }

  saveBook(){
    this.bookService.createBook(this.book).subscribe(data=>{
      console.log(data);
      alert("added successfully")
      
      },
      error=>console.log(error));
  }

  getAllBook(){
   this.router.navigate(['book-dash']);
  }
  

  onSubmit(){
    console.log(this.book);
    this.saveBook();

  }

}
