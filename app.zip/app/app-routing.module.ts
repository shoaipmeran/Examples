import { NgModule, Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookdashboardComponent } from './bookdashboard/bookdashboard.component';
import { AddbookComponent } from './addbook/addbook.component';
import { UpdatebookComponent } from './updatebook/updatebook.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ReaderComponent } from './reader/reader.component';
import { ReaderdashboardComponent } from './readerdashboard/readerdashboard.component';
import { SearchbookComponent } from './searchbook/searchbook.component';
//import { UserdashboardComponent } from './userdashboard/userdashboard.component';
import { SubscriberComponent } from './subscriber/subscriber.component';
import { SubscriberListComponent } from './subscriber-list/subscriber-list.component';
import { BooklistComponent } from './booklist/booklist.component';
import { HeaderComponent } from './header/header.component';



const routes: Routes = [

  //{path:'',redirectTo:'header',pathMatch:'full'},
  {path: 'header', component:HeaderComponent},

  {path:'',redirectTo:'login',pathMatch:'full'},
  {path: 'login', component:LoginComponent},

  {path:'book-dash',component:BookdashboardComponent},

  {path:'addbook',component:AddbookComponent},
  
  {path:'updatebook/:id', component:UpdatebookComponent},
  
  {path: 'register', component:RegisterComponent},
 // {path: 'reader',component:ReaderComponent},
  {path: 'reader',component:ReaderdashboardComponent},
  {path: 'searchbook',component:SearchbookComponent},
  //{path: 'user-dash',component:UserdashboardComponent},
  {path: 'subscriber/:id',component:SubscriberComponent},
  {path: 'subcriber-list',component:SubscriberListComponent},
 // {path: 'user-dash', component:UserdashboardComponent},
  {path: 'booklist/:id',component:BooklistComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
