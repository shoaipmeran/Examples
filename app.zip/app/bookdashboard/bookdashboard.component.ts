import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Book } from '../module/book';
import { BookserviceService } from '../service/bookservice.service';

@Component({
  selector: 'app-bookdashboard',
  templateUrl: './bookdashboard.component.html',
  styleUrls: ['./bookdashboard.component.scss']
})
export class BookdashboardComponent implements OnInit {
   
  name:any = sessionStorage.getItem("name");
  idauthor:any = sessionStorage.getItem("id");
  
  books!:any;

  constructor(private bookService:BookserviceService,private router:Router) { }

  ngOnInit(): void {
    console.log(name);
    this.getBookByAuthor(this.idauthor)
  }

  addBook(){
    this.router.navigate(['addbook'])
  }
  
  getBookByAuthor(idauthor:string){
    this.bookService.searchBooksByAuthor(idauthor).subscribe(data=>{
      this.books=data;
    })
  }
  getAllBook(){
    this.bookService.getBookList().subscribe(data=>{
      this.books=data;
    })
  }

  updateBook(id:number){
    this.router.navigate(['updatebook', id]);
  }

}
