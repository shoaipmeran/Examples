import { Component, OnInit } from '@angular/core';
import { Book } from '../module/book';
import { BookserviceService } from '../service/bookservice.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit {
  bookData:any;
   data1:any;
  id: any;
  book:Book=new Book();
  constructor(private bookService:BookserviceService,private router:Router,private route:ActivatedRoute) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    this.bookDetails(this.id)
  }

  bookDetails(id:any){
    this.bookService.getBookId(id).subscribe((data) => {
     this.data1=data;
     this.bookData = data;
    console.log(data);
  })
}

}
