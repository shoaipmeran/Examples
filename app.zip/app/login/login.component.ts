import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../module/user';
import { UserserviceService } from '../service/userservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm!:FormGroup;
  user:User=new User();
  data:{}|any;
  constructor(private userService:UserserviceService,private router:Router) { }

  ngOnInit(): void {
    sessionStorage.clear();
  }

  login(){
    this.userService.login(this.user).subscribe(data=>{
      console.log("inside login") 
      console.log(data)
      if (data.messagess == "User signed-in successfully" && data.role=="Author") {
          let role=data.role;
          let name=data.name;
          sessionStorage.setItem("role", role);
          sessionStorage.setItem("name", name);
          sessionStorage.setItem("id", data.id);
          sessionStorage.setItem("email", data.email);
          sessionStorage.setItem("isUserValid", "true");

          console.log(sessionStorage.getItem("name"));
          
        
        this.router.navigate(['/book-dash'])
      }
      else if(data.messagess == "User signed-in successfully" && data.role=="Reader"){
        sessionStorage.setItem("role", data.role);
          sessionStorage.setItem("name", data.name);
          sessionStorage.setItem("id", data.id);
          sessionStorage.setItem("email", data.email);
          sessionStorage.setItem("isUserValid", "true");
        this.router.navigate(['/reader'])
      }
      else{
        alert("some issue");
      }
      if(data.messages=="Password is incorrect"){
        alert("invalid password")
      }

      if(data.messages=="User not found"){
        alert("User not found")
      }
      
    },error=>{
      console.log(error);
    })
    
  }

  register(){
  this.router.navigate(['register'])
  }

}
