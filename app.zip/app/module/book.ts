export class Book {

    book_id:number|any;
    author_id:number|any;
    logo:String|any;
    title:String|any;
    category:String|any;
    price:number|any;
    author:String|any;
    publisher:String|any;
    published_date:Date|any;
    content:String|any;
    active:boolean|any;
    //created_on:Date|any;

}
