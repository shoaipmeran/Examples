import { Reader } from './reader';

describe('Reader', () => {
  it('should create an instance', () => {
    expect(new Reader()).toBeTruthy();
  });
});
