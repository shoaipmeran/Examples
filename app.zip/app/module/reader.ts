export class Reader {
    subscriptionId:number|any;
    totalBillAmount:number|any;
    dateofSubscribe:String|any;
    email:String|any;
    bidfk:number|any;
}
