export class User {
    id:number|any;
    email:String|any;
    password:String|any;
    role:String|any;
    name:String|any;
    messagess:String|any;
}
