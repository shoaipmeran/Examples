import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Book } from '../module/book';
import { BookserviceService } from '../service/bookservice.service';

@Component({
  selector: 'app-readerdashboard',
  templateUrl: './readerdashboard.component.html',
  styleUrls: ['./readerdashboard.component.scss']
})
export class ReaderdashboardComponent implements OnInit {
  
  books!:Book[];
  name:any = sessionStorage.getItem("name");
  idauthor:any = sessionStorage.getItem("id");
  
  constructor(private bookService:BookserviceService,private router:Router ) { }

  ngOnInit(): void {
    this.getAllBook();
  }

  getAllBook(){
    this.bookService.getBookList().subscribe(data=>{
      this.books=data;
    })
  }

  subscribe(book:Book){
    this.router.navigate(['subscriber',book.book_id])
  }

}
