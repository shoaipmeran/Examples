import { Component, OnInit } from '@angular/core';
import { User } from '../module/user';
import { UserserviceService } from '../service/userservice.service';
import { Router } from '@angular/router';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
user:User=new User();

  constructor(private userService:UserserviceService,private router:Router) { }
  ngForm!:FormGroup;
  ngOnInit(): void {
    
  }

  register(){
    this.userService.register(this.user).subscribe(data=>{
      console.log(data.email)
      if(data.email=="User registered successfully"){
        alert("user register successsfully")
        this.router.navigate(['/login'])
    }
      else{
        
        alert("email id already taken")
      }
    },error=>{
      console.log(error);
      alert("user register unsuccesssfull")
    })

  }

}
