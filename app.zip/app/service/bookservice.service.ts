import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Book } from '../module/book';

@Injectable({
  providedIn: 'root'
})
export class BookserviceService {

  addBookURL : string;
  getBookURL : string;
  putBookURL : string;
  deleteBookURL:string;
  getBookIdURL:string;
  getBookURL1:string;
 

  constructor(private http:HttpClient) { 

    this.addBookURL='http://localhost:7001/api/v1/digitalbooks'
    this.getBookURL='http://localhost:7001/api/v1/digitalbooks'
    this.putBookURL='http://localhost:7001/api/v1/digitalbooks'
    this.deleteBookURL='http://localhost:7001/api/v1/digitalbooks'
    this.getBookIdURL='http://localhost:7001/api/v1/digitalbooks'
    this.getBookURL1='http://localhost:7001/api/v1/digitalbooks'
   
  }


  getBookList():Observable<Book[]>{
    return this.http.get<Book[]>(`${this.getBookURL}`);
  }

  createBook(book:Book):Observable<Object>{
    return this.http.post(`https://hiijw3nuue.execute-api.ap-northeast-1.amazonaws.com//api/v1/digitalbooks/author/4/books`,book);
  }

  updateBook(id:number,book:Book):Observable<Object>{
    return this.http.put(`${this.putBookURL}${id}`,book);
  }

 
  getBookId(id:number):Observable<Book>{
    return this.http.get<Book>(`${this.getBookIdURL}${id}`);
  }


  searchBooks(category:any,title:any,author:any,price:any,publisher:any){//pending
  console.log(category);
  //console.log(dates);
    // return this.http.get('http://localhost:7001/api/v1/digitalbooks/searchbook?category=${category}&title=${title}&author=${author}&price=${price}&publisher=${publisher}');
   return this.http.get('http://localhost:7001/api/v1/digitalbooks/searchbook?category='+category+'&title='+title+'&author='+author+'&price='+price+'&publisher='+publisher); 
  }
   
   searchBooksByAuthor(author:any){//completed
    console.log('inside book service author search reader controll port 9000 '+ author)
    return this.http.get(`http://localhost:7001/api/v1/digitalbooks/author/${author}`);
   }
   

    searchBooksbydate(dates:any){//pending
      console.log(dates);
        // return this.http.get('http://localhost:7001/api/v1/digitalbooks/searchbook?category=${category}&title=${title}&author=${author}&price=${price}&publisher=${publisher}');
        return this.http.get(`http://localhost:7001/api/v1/digitalbooks/searchbookbytitle/${dates}`);
      }
}
