import { TestBed } from '@angular/core/testing';

import { ReaderserviceService } from './readerservice.service';

describe('ReaderserviceService', () => {
  let service: ReaderserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ReaderserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
