import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {Reader} from '../module/reader'

@Injectable({
  providedIn: 'root'
})
export class ReaderserviceService {
  
  addReaderURL : string;
  getReaderURL : string;
  deleteReaderURL:string;
  

  constructor(private http:HttpClient) { 
    this.addReaderURL='http://localhost:7001/api/v1/digitalbooks'
    this.getReaderURL='http://localhost:7001/api/v1/digitalbooks'
    this.deleteReaderURL='http://localhost:7001/api/v1/digitalbooks'
    
  }

  
  getReaderList():Observable<Reader[]>{
    return this.http.get<Reader[]>(`${this.getReaderURL}`);
  }

  createReader(reader:Reader,id:number):Observable<Object>{
    return this.http.post(`${this.addReaderURL}${id}`,reader);
  }

  deleteReader(id:number):Observable<Object>{
    return this.http.delete(`${this.deleteReaderURL}/${id}`);
  }
}

