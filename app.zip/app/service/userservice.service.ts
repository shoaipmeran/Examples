import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../module/user';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserserviceService {

  post: any;
  userRegister:String;
  userLogin:String;
  getUserURL:String;

  constructor(private http:HttpClient) { 
    this.userRegister='https://hiijw3nuue.execute-api.ap-northeast-1.amazonaws.com/api/v1/digitalbooks/sign-up'
    this.userLogin='https://hiijw3nuue.execute-api.ap-northeast-1.amazonaws.com/api/v1/digitalbooks/sign-in'
    this.getUserURL='http://localhost:7001/api/v1/digitalbooks/searchbook'
  }

  register(user:User):Observable<any>{
    console.log('testtt');
    return this.http.post<User>(`${this.userRegister}`,user)
  }

  login(user:User):Observable<any>{
    console.log('testtt');
    return this.http.post<User>(`${this.userLogin}`,user)
  }

  getUserList():Observable<User[]>{
    return this.http.get<User[]>(`${this.getUserURL}`);
  }
  
  

}
