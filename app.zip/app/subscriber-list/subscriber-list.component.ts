import { Component, OnInit } from '@angular/core';
import { Reader } from '../module/reader';
import { ReaderserviceService } from '../service/readerservice.service';
import { Router } from '@angular/router';
import { Book } from '../module/book';

@Component({
  selector: 'app-subscriber-list',
  templateUrl: './subscriber-list.component.html',
  styleUrls: ['./subscriber-list.component.css']
})
export class SubscriberListComponent implements OnInit {
  readers!:Reader[];
  bookId:any;
  name:any = sessionStorage.getItem("name");
  idauthor:any = sessionStorage.getItem("id");
  book:Book=new Book();
  constructor(private readerService:ReaderserviceService,private router:Router) { }

  ngOnInit(): void {
    this.getAllReaders();
  }

  getAllReaders(){
    this.readerService.getReaderList().subscribe(data=>{
      this.readers=data;
    })
  }

 
  onsubmit(){
    this.router.navigate(['/reader'])
  }

  unsubscribe(id:number){
    this.readerService.deleteReader(id).subscribe((data: any)=>{
      console.log(data);
      this.getAllReaders();
    })
    this.ngOnInit();
    this.getAllReaders();
  }
  }


