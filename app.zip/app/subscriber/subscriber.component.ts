import { Component, OnInit } from '@angular/core';
import { Reader } from '../module/reader';
import { ReaderserviceService } from '../service/readerservice.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-subscriber',
  templateUrl: './subscriber.component.html',
  styleUrls: ['./subscriber.component.css']
})
export class SubscriberComponent implements OnInit {
  
  id:any;
  bookId:any;
  reader:Reader=new Reader();
  constructor(private readerService:ReaderserviceService,private route:ActivatedRoute,private router:Router) { }

  ngOnInit(): void {
    this.id=this.route.snapshot.paramMap.get('id');
    console.log('id=',this.id);
    this.bookId=parseInt(this.id);
  }

  saveReader(){
    console.log('in add reader=',this.bookId)
    console.log('in add reader=',this.reader)
    this.readerService.createReader(this.reader,this.bookId).subscribe(data=>{
      console.log(data)
      this.router.navigate(['/subcriber-list'])
    },error=>{
      console.log(error);
    })
   }

}
