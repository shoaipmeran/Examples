import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Book } from '../module/book';
import { BookserviceService } from '../service/bookservice.service';

@Component({
  selector: 'app-updatebook',
  templateUrl: './updatebook.component.html',
  styleUrls: ['./updatebook.component.css']
})
export class UpdatebookComponent implements OnInit {

  book: Book = new Book();
  id: any;

  constructor(private bookService: BookserviceService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {

    this.id = this.route.snapshot.params['id'];
    this.bookService.getBookId(this.id).subscribe(data => {
      console.log(data);
      this.book = data;
    })

  }

  onupdate() {
    this.bookService.updateBook(this.id, this.book).subscribe(data => {
      console.log(data);
      this.book = new Book();
      alert("Updated successfully ");
      this.router.navigate(['book-dash'])
      //this.getAllMember();
    }, error => {
      console.log(error);
      this.router.navigate(['book-dash'])
    })

  }

  onSubmit() {

    console.log(this.id, this.book);
    this.onupdate();

  }
}
